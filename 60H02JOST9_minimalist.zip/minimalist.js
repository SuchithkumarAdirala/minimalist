function togglePopup() {
    document.getElementById("popUp").classList.toggle("active");
}